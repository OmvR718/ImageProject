
#include "stdio.h"

main()
{
   printf("\a\a\a\a");
}
