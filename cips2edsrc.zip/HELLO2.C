
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>


/*****************************************************/
/*****************************************************/

hello2()
{

   printf("\nHello 2222 world this is a test");

}
