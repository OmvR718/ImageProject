   for(i=0; i<ROWS; i++)
      for(j=0; j<COLS; j++)
